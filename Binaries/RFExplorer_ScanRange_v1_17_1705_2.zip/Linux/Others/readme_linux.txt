The <generic> Linux approach to run ScanRange tool requires:

* Mono installed (see www.mono-project.com for more details)
* Silabs CP210x driver installed - most modern Linux kernel distro include that, otherwise check in the Silabs site.
* run with "sudo mono RFExplorer_ScanRange.exe" or, alternatively, use mkbundle mono tool to create a compact Linux native tool for your specific distro version